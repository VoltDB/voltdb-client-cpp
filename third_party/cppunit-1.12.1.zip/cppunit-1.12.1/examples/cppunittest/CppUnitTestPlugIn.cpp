#include <cppunit/plugin/TestPlugIn.h>


// Implements all the plug-in stuffs, WinMain...
CPPUNIT_PLUGIN_IMPLEMENT();
